<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');

// Auth
$routes->post('api/login', 'AuthController::login');
$routes->post('api/logout', 'AuthController::logout', ['filter' => 'auth']);

// Kategori
$routes->get('api/kategori', 'KategoriController::index');
$routes->get('api/kategori/(:num)', 'KategoriController::show/$1');
$routes->post('api/kategori', 'KategoriController::create', ['filter' => 'auth']);
$routes->put('api/kategori/(:num)', 'KategoriController::update/$1', ['filter' => 'auth']);
$routes->delete('api/kategori/(:num)', 'KategoriController::delete/$1', ['filter' => 'auth']);

// Buku
$routes->get('api/buku', 'BukuController::index');
$routes->get('api/buku/(:num)', 'BukuController::show/$1');
$routes->post('api/buku', 'BukuController::create', ['filter' => 'auth']);
$routes->put('api/buku/(:num)', 'BukuController::update/$1', ['filter' => 'auth']);
$routes->delete('api/buku/(:num)', 'BukuController::delete/$1', ['filter' => 'auth']);
