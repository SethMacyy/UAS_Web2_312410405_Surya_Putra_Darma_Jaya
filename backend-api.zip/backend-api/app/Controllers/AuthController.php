<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class AuthController extends ResourceController
{
    public function login()
    {
        $username = $this->request->getJSON()->username ?? '';
        $password = $this->request->getJSON()->password ?? '';

        $db = \Config\Database::connect();
        $user = $db->table('users')->where('username', $username)->get()->getRow();

        if (!$user || !password_verify($password, $user->password)) {
            return $this->response->setStatusCode(401)
                ->setJSON(['status' => 401, 'message' => 'Login gagal']);
        }

        $token = bin2hex(random_bytes(32));
        $db->table('users')->where('id', $user->id)->update(['token' => $token]);

        return $this->response->setJSON([
            'status'  => 200,
            'message' => 'Login berhasil',
            'token'   => $token
        ]);
    }

    public function logout()
    {
        $token = str_replace('Bearer ', '', $this->request->getHeaderLine('Authorization'));
        $db = \Config\Database::connect();
        $db->table('users')->where('token', $token)->update(['token' => null]);

        return $this->response->setJSON(['status' => 200, 'message' => 'Logout berhasil']);
    }
}