<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class BukuController extends ResourceController
{
    protected $db;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
    }

    public function index()
    {
        $data = $this->db->table('buku b')
            ->select('b.*, k.nama_genre')
            ->join('kategori k', 'k.id = b.kategori_id')
            ->get()->getResultArray();
        return $this->response->setJSON(['status' => 200, 'data' => $data]);
    }

    public function show($id = null)
    {
        $data = $this->db->table('buku b')
            ->select('b.*, k.nama_genre')
            ->join('kategori k', 'k.id = b.kategori_id')
            ->where('b.id', $id)->get()->getRowArray();
        if (!$data) return $this->response->setStatusCode(404)->setJSON(['status' => 404, 'message' => 'Tidak ditemukan']);
        return $this->response->setJSON(['status' => 200, 'data' => $data]);
    }

    public function create()
    {
        $json = $this->request->getJSON();
        $data = [
            'judul'       => $json->judul,
            'penulis'     => $json->penulis,
            'kategori_id' => $json->kategori_id,
            'stok'        => $json->stok ?? 0,
            'status'      => $json->status ?? 'tersedia'
        ];
        $this->db->table('buku')->insert($data);
        return $this->response->setJSON(['status' => 201, 'message' => 'Buku ditambahkan']);
    }

    public function update($id = null)
    {
        $json = $this->request->getJSON();
        $data = [
            'judul'       => $json->judul,
            'penulis'     => $json->penulis,
            'kategori_id' => $json->kategori_id,
            'stok'        => $json->stok ?? 0,
            'status'      => $json->status ?? 'tersedia'
        ];
        $this->db->table('buku')->where('id', $id)->update($data);
        return $this->response->setJSON(['status' => 200, 'message' => 'Buku diupdate']);
    }

    public function delete($id = null)
    {
        $this->db->table('buku')->where('id', $id)->delete();
        return $this->response->setJSON(['status' => 200, 'message' => 'Buku dihapus']);
    }
}