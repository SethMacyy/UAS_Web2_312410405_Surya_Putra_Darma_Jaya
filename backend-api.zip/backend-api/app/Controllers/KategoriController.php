<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class KategoriController extends ResourceController
{
    protected $db;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
    }

    public function index()
    {
        $data = $this->db->table('kategori')->get()->getResultArray();
        return $this->response->setJSON(['status' => 200, 'data' => $data]);
    }

    public function show($id = null)
    {
        $data = $this->db->table('kategori')->where('id', $id)->get()->getRowArray();
        if (!$data) return $this->response->setStatusCode(404)->setJSON(['status' => 404, 'message' => 'Tidak ditemukan']);
        return $this->response->setJSON(['status' => 200, 'data' => $data]);
    }

    public function create()
    {
        $data = [
            'nama_genre' => $this->request->getJSON()->nama_genre,
            'deskripsi'  => $this->request->getJSON()->deskripsi ?? ''
        ];
        $this->db->table('kategori')->insert($data);
        return $this->response->setJSON(['status' => 201, 'message' => 'Kategori ditambahkan']);
    }

    public function update($id = null)
    {
        $data = [
            'nama_genre' => $this->request->getJSON()->nama_genre,
            'deskripsi'  => $this->request->getJSON()->deskripsi ?? ''
        ];
        $this->db->table('kategori')->where('id', $id)->update($data);
        return $this->response->setJSON(['status' => 200, 'message' => 'Kategori diupdate']);
    }

    public function delete($id = null)
    {
        $this->db->table('kategori')->where('id', $id)->delete();
        return $this->response->setJSON(['status' => 200, 'message' => 'Kategori dihapus']);
    }
}